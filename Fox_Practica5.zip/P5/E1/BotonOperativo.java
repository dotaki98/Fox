public class BotonOperativo{

	private String accion;

}
