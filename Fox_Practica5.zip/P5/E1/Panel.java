public class Panel{

	private ArrayList<Boton> digitos;
	private Boton entrada;

	public void mostrarValorPantalla(Boton boton){

	}

	public void ejecutarAccion(Boton boton{

	}

}
