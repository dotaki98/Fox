public class Alarma{

	private String marca;
	private String modelo;
	private Panel panel;
	private Bocina bocina;
	private int codigo;
	private Date hora;
	private Date horaInicio;
	private Date horaFin;
	private ArrayList<Sensor> sensores;
	private Bateria bateria;
	private boolean corrienteElectrica;
	private int tiempoActivacion;
	private boolean esActiva;

	public void registrarCodigo(int codigo){

	}

	public void activarBocina(){

	}

	public void cambiarHoraInicio(Date horaInicio){

	}

	public void cambiarHoraFin(Date horaFin){

	}

	public void monitorearSensores(){

	}

	public void monitorearCorrienteElectrica(){

	}

	public void activarAlarma(){

	}

	public void desactivarAlarma(){

	}

	public void configurarAlarma(){

	}

	public void configurarTiempoActivacion(int tiempoActivacion){

	}

}
