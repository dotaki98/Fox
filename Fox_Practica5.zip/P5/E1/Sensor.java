public class Sensor{

	private String tipo;
	private boolean activa;

	public boolean enviarEstado(){

	}

	public void monitorearAcceso(){
		
	}


}
