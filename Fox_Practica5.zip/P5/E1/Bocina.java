public class Bocina(){
	private int volumen;

	public void emitirSonido(){
	}

}
