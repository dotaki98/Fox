public class Bateria{

	private int carga;

	public void cargarBateria(int carga){

	}

	public void energizarComponente(){

	}

}
