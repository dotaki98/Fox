public class BotonNumerico{

	private int valor;

}
