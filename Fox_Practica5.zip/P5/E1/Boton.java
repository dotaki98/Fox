public class Boton{

	private String tipo;
	private boolean activo;

	public void cambiarEstado(boolean activo){

	}

}
