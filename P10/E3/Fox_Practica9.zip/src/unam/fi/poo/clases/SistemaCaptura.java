package unam.fi.poo.clases;

import unam.fi.poo.graficos.VentanaPrincipal;

public class SistemaCaptura {

	public SistemaCaptura() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		new VentanaPrincipal();
	}



}
