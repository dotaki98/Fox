public class Motor{
		
	private String marca;
	private String modelo;
	private int potencia;

	public String getMarca(){
		return this.marca;
	}

	public void setMarca(String marca){
		this.marca = marca;
	}

	
	public String getModelo(){
		return this.modelo;
	}

	public void setModelo(String modelo){
		this.modelo = modelo;
	}

	public int getPotencia(){
		return this.potencia;
	}

	public void setPotencia(int potencia){
		this.potencia = potencia;
	}

}
