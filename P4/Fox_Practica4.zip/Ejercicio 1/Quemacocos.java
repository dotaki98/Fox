public class Quemacocos{
	
	private boolean electrico;

	public boolean getElectrico(){
		return this.electrico;
	}

	public void setElectrico(boolean electrico){
		this.electrico = electrico;
	}

	public void abrir(){
		System.out.println("La clase Quemacocos esta ejecutando el metodo abrir");
	}

	public void cerrar(){
		System.out.println("La clase Quemacocos esta ejecutando el metodo cerrar");
	}

}
